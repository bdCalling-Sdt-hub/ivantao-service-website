// export const base_url = "http://10.0.80.16:8002/api";
export const base_url = "http://182.252.68.227:8006/api";
export const defaultUserProfile =
  "https://api.dicebear.com/9.x/big-ears-neutral/svg?eyes=variant03&mouth=variant0702&nose=variant01&backgroundColor=ffffff";
