import React from "react";

export default function AppTable() {
  return <div>AppTable</div>;
}
