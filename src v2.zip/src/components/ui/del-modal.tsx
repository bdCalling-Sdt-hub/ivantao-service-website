import React from "react";

export default function DelModal() {
  return <div>DelModal</div>;
}
