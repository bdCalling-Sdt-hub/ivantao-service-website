export const services = [
  {
    image: "/images/service/1.webp",
    title: "Everyday essentials",
    description:
      "Lorem ipsum dolor sit amet consectetur. Posuere odio molestie tellus nunc semper maecenas. Ultrices ipsum nullam ornare morbi auctor. Aliquet fermentum feugiat fusce aliquam nullam lacus mauris. Feugiat sed viverra ultrices purus amet quis consequat tellus. Tortor pellentesque urna sit purus.",
  },
  {
    image: "/images/service/2.webp",
    title: "Household",
    description:
      "Lorem ipsum dolor sit amet consectetur. Posuere odio molestie tellus nunc semper maecenas. Ultrices ipsum nullam ornare morbi auctor. Aliquet fermentum feugiat fusce aliquam nullam lacus mauris. Feugiat sed viverra ultrices purus amet quis consequat tellus. Tortor pellentesque urna sit purus.",
  },
  {
    image: "/images/service/3.webp",
    title: "Creative",
    description:
      "Lorem ipsum dolor sit amet consectetur. Posuere odio molestie tellus nunc semper maecenas. Ultrices ipsum nullam ornare morbi auctor. Aliquet fermentum feugiat fusce aliquam nullam lacus mauris. Feugiat sed viverra ultrices purus amet quis consequat tellus. Tortor pellentesque urna sit purus.",
  },
  {
    image: "/images/service/4.webp",
    title: "Information technology",
    description:
      "Lorem ipsum dolor sit amet consectetur. Posuere odio molestie tellus nunc semper maecenas. Ultrices ipsum nullam ornare morbi auctor. Aliquet fermentum feugiat fusce aliquam nullam lacus mauris. Feugiat sed viverra ultrices purus amet quis consequat tellus. Tortor pellentesque urna sit purus.",
  },
  {
    image: "/images/service/5.webp",
    title: "Professional",
    description:
      "Lorem ipsum dolor sit amet consectetur. Posuere odio molestie tellus nunc semper maecenas. Ultrices ipsum nullam ornare morbi auctor. Aliquet fermentum feugiat fusce aliquam nullam lacus mauris. Feugiat sed viverra ultrices purus amet quis consequat tellus. Tortor pellentesque urna sit purus.",
  },
  {
    image: "/images/service/6.webp",
    title: "Education",
    description:
      "Lorem ipsum dolor sit amet consectetur. Posuere odio molestie tellus nunc semper maecenas. Ultrices ipsum nullam ornare morbi auctor. Aliquet fermentum feugiat fusce aliquam nullam lacus mauris. Feugiat sed viverra ultrices purus amet quis consequat tellus. Tortor pellentesque urna sit purus.",
  },
  {
    image: "/images/service/7.webp",
    title: "Specialized",
    description:
      "Lorem ipsum dolor sit amet consectetur. Posuere odio molestie tellus nunc semper maecenas. Ultrices ipsum nullam ornare morbi auctor. Aliquet fermentum feugiat fusce aliquam nullam lacus mauris. Feugiat sed viverra ultrices purus amet quis consequat tellus. Tortor pellentesque urna sit purus.",
  },
  {
    image: "/images/service/8.webp",
    title: "Commercial",
    description:
      "Lorem ipsum dolor sit amet consectetur. Posuere odio molestie tellus nunc semper maecenas. Ultrices ipsum nullam ornare morbi auctor. Aliquet fermentum feugiat fusce aliquam nullam lacus mauris. Feugiat sed viverra ultrices purus amet quis consequat tellus. Tortor pellentesque urna sit purus.",
  },
];

export const products = [
  {
    imageSrc: "/images/service/1.webp",
    title: "Sophia Bennett",
    rating: 4.9,
    reviewCount: 225,
    description:
      "Lorem ipsum dolor sit amet consectetur. Dictum cras facilisi nunc facilisis. Eleifend vel sed donec felis libero. In imperdiet pellentesque at urna velit in massa potenti. Id eleifend nulla odio dignissim malesuada est egestas congue arcu.",
    price: 52.0,
  },
  {
    imageSrc: "/images/service/1.webp",
    title: "Sophia Bennett",
    rating: 4.9,
    reviewCount: 225,
    description:
      "Lorem ipsum dolor sit amet consectetur. Dictum cras facilisi nunc facilisis. Eleifend vel sed donec felis libero. In imperdiet pellentesque at urna velit in massa potenti. Id eleifend nulla odio dignissim malesuada est egestas congue arcu.",
    price: 52.0,
  },
  {
    imageSrc: "/images/service/1.webp",
    title: "Sophia Bennett",
    rating: 4.9,
    reviewCount: 225,
    description:
      "Lorem ipsum dolor sit amet consectetur. Dictum cras facilisi nunc facilisis. Eleifend vel sed donec felis libero. In imperdiet pellentesque at urna velit in massa potenti. Id eleifend nulla odio dignissim malesuada est egestas congue arcu.",
    price: 52.0,
  },

  {
    imageSrc: "/images/service/1.webp",
    title: "Sophia Bennett",
    rating: 4.9,
    reviewCount: 225,
    description:
      "Lorem ipsum dolor sit amet consectetur. Dictum cras facilisi nunc facilisis. Eleifend vel sed donec felis libero. In imperdiet pellentesque at urna velit in massa potenti. Id eleifend nulla odio dignissim malesuada est egestas congue arcu.",
    price: 52.0,
  },
  {
    imageSrc: "/images/service/1.webp",
    title: "Sophia Bennett",
    rating: 4.9,
    reviewCount: 225,
    description:
      "Lorem ipsum dolor sit amet consectetur. Dictum cras facilisi nunc facilisis. Eleifend vel sed donec felis libero. In imperdiet pellentesque at urna velit in massa potenti. Id eleifend nulla odio dignissim malesuada est egestas congue arcu.",
    price: 52.0,
  },
  {
    imageSrc: "/images/service/1.webp",
    title: "Sophia Bennett",
    rating: 4.9,
    reviewCount: 225,
    description:
      "Lorem ipsum dolor sit amet consectetur. Dictum cras facilisi nunc facilisis. Eleifend vel sed donec felis libero. In imperdiet pellentesque at urna velit in massa potenti. Id eleifend nulla odio dignissim malesuada est egestas congue arcu.",
    price: 52.0,
  },

  {
    imageSrc: "/images/service/1.webp",
    title: "Sophia Bennett",
    rating: 4.9,
    reviewCount: 225,
    description:
      "Lorem ipsum dolor sit amet consectetur. Dictum cras facilisi nunc facilisis. Eleifend vel sed donec felis libero. In imperdiet pellentesque at urna velit in massa potenti. Id eleifend nulla odio dignissim malesuada est egestas congue arcu.",
    price: 52.0,
  },
  {
    imageSrc: "/images/service/1.webp",
    title: "Sophia Bennett",
    rating: 4.9,
    reviewCount: 225,
    description:
      "Lorem ipsum dolor sit amet consectetur. Dictum cras facilisi nunc facilisis. Eleifend vel sed donec felis libero. In imperdiet pellentesque at urna velit in massa potenti. Id eleifend nulla odio dignissim malesuada est egestas congue arcu.",
    price: 52.0,
  },
  {
    imageSrc: "/images/service/1.webp",
    title: "Sophia Bennett",
    rating: 4.9,
    reviewCount: 225,
    description:
      "Lorem ipsum dolor sit amet consectetur. Dictum cras facilisi nunc facilisis. Eleifend vel sed donec felis libero. In imperdiet pellentesque at urna velit in massa potenti. Id eleifend nulla odio dignissim malesuada est egestas congue arcu.",
    price: 52.0,
  },
];
